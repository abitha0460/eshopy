<?php
$con=mysqli_connect("localhost","root","","db-login");
if(!$con)
{
    die("connection failed");
}
?>
